<?php
require_once 'includes/config.php';
$page_title = "Accueil - E-Tontine";

if (isLoggedIn()) {
    redirect('pages/dashboard.php');
}

// Tontines populaires
$stmtT = $db->query("SELECT nom, frequence FROM tontines ORDER BY id DESC LIMIT 3");
$tontines = $stmtT->fetchAll();

// Membres actifs
$stmtU = $db->query("SELECT nom FROM users ORDER BY id DESC LIMIT 5");
$membres = $stmtU->fetchAll();

// Témoignages fictifs ou issus de table avis
$avis = [
    ["nom" => "Aïcha", "texte" => "E-Tontine m'a permis de rejoindre un groupe fiable et structuré."],
    ["nom" => "Mamadou", "texte" => "La transparence et l’historique des versements sont excellents."],
    ["nom" => "Fatou", "texte" => "On gère notre tontine comme une vraie entreprise. Bravo !"]
];
?>

<?php include 'includes/header.php'; ?>

<style>
.hero {
  background: url('assets/img/background-tontine.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  color: white;
  text-align: center;
  padding: 100px 30px;
  position: relative;
  min-height: 400px;
}
.hero-content {
  background-color: rgba(0, 123, 255, 0.7);
  display: inline-block;
  padding: 40px;
  border-radius: 10px;
}
.hero a {
  background: white;
  color: #007bff;
  font-weight: bold;
  padding: 12px 24px;
  border-radius: 6px;
  text-decoration: none;
  margin-top: 20px;
  display: inline-block;
}
section {
  padding: 60px 30px;
}
section h2 {
  text-align: center;
  color: #007bff;
  margin-bottom: 30px;
}
.card, .avatar, .testimonial {
  background: white;
  border-radius: 10px;
  box-shadow: 0 0 8px rgba(0,0,0,0.1);
  padding: 20px;
  margin: 10px auto;
}
.card img, .motivation img, .about img, .don img {
  width: 100%;
  border-radius: 8px;
  margin-bottom: 10px;
}
.avatar {
  display: inline-block;
  width: 100px;
  height: 100px;
  background: #007bff;
  color: white;
  border-radius: 50%;
  line-height: 100px;
  font-weight: bold;
  margin: 10px;
}
.card {
  transition: transform 0.3s ease;
}
.card:hover {
  transform: scale(1.02);
}
#avis-slider .slide {
  display: none;
}
#avis-slider .slide.active {
  display: block;
}
.motivation {
  background: linear-gradient(to right, #00c6ff, #0072ff);
  color: white;
  padding: 60px 30px;
  text-align: center;
}
.motivation h2 {
  margin-bottom: 20px;
  font-size: 2.5rem;
}
.motivation p {
  font-size: 1.2rem;
  max-width: 800px;
  margin: auto;
}
.motivation a {
  margin-top: 20px;
  display: inline-block;
  padding: 12px 30px;
  background: white;
  color: #007bff;
  font-weight: bold;
  border-radius: 6px;
  text-decoration: none;
}
.about, .don {
  background: #f8f9fa;
}
.about p, .don p {
  max-width: 800px;
  margin: auto;
  font-size: 1.1rem;
  line-height: 1.6;
  color: #333;
  text-align: center;
}
.don a {
  background: #007bff;
  color: white;
  padding: 12px 24px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: bold;
  display: inline-block;
  margin-top: 20px;
}
</style>

<section class="hero">
  <div class="hero-content">
    <h1 style="font-size: 3rem;">Gérez vos tontines avec sécurité</h1>
    <p style="font-size: 1.2rem;">La plateforme E-Tontine vous offre transparence, sécurité et accessibilité.</p>
    <a href="pages/auth/login.php">S'inscrire gratuitement</a>
  </div>
</section>

<section>
  <h2>🌟 Tontines Populaires</h2>
  <div style="display: flex; justify-content: center; gap: 20px; flex-wrap: wrap;">
    <?php foreach ($tontines as $t): ?>
      <div class="card" style="width:280px;">
        <img src="assets/img/tontine-icon.jpg" alt="Tontine">
        <h3><?= htmlspecialchars($t['nom']) ?></h3>
        <p><strong>Fréquence :</strong> <?= ucfirst($t['frequence']) ?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<section>
  <h2>👥 Membres actifs</h2>
  <div style="text-align:center;">
    <?php foreach ($membres as $m): ?>
      <div class="avatar"><?= htmlspecialchars($m['nom']) ?></div>
    <?php endforeach; ?>
  </div>
</section>

<section>
  <h2>📢 Témoignages</h2>
  <div id="avis-slider" style="max-width:800px; margin:30px auto;">
    <?php foreach ($avis as $index => $a): ?>
      <div class="slide <?= $index === 0 ? 'active' : '' ?> testimonial">
        <img src="assets/img/user-<?= $index+1 ?>.jpg" alt="<?= $a['nom'] ?>" style="width:50px; border-radius:50%; margin-bottom:10px;">
        <p><strong><?= htmlspecialchars($a['nom']) ?> :</strong> <?= htmlspecialchars($a['texte']) ?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<section class="about">
  <h2>💡 À propos de nous</h2>
  <p>
    E-Tontine est une plateforme dédiée à la digitalisation des tontines traditionnelles. 
    Notre mission est d'offrir aux communautés un outil moderne, fiable et sécurisé pour gérer leurs épargnes collectives.
    Nous croyons en la solidarité, l'entraide et la transparence. 
  </p>
</section>

<section class="motivation">
  <img src="assets/img/group-solidarity.jpg" alt="Solidarité" style="max-width:300px; margin-bottom:20px;">
  <h2>Lance ta tontine dès aujourd'hui</h2>
  <p>
    Épargner ensemble, c’est avancer ensemble. Tu as des proches ou collègues de confiance ? Alors crée ta propre tontine sécurisée sur E-Tontine. Rejoins une communauté qui valorise l’entraide et l’organisation financière intelligente.
  </p>
  <a href="pages/creer_tontine.php">Créer ma tontine</a>
</section>

<section class="don">
  <h2>🎁 Faire un don</h2>
  <p>
    Soutenez notre projet communautaire et contribuez à rendre la finance solidaire accessible à tous.
    Aucun compte nécessaire, il suffit d’avoir le cœur généreux 💙
  </p>
  <a href="pages/don.php">Faire un don maintenant</a>
</section>

<script>
  const slides = document.querySelectorAll('#avis-slider .slide');
  let index = 0;
  if (slides.length > 0) {
    setInterval(() => {
      slides.forEach((s, i) => s.classList.toggle('active', i === index));
      index = (index + 1) % slides.length;
    }, 4000);
  }

  console.log('%cBienvenue sur E-Tontine 🎉', 'color:#007bff; font-size:16px; font-weight:bold;');
</script>

<script src="assets/js/script.js"></script>

<?php include 'includes/footer.php'; ?>