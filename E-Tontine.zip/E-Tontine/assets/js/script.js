document.addEventListener('DOMContentLoaded', function() {
  // Confirmation pour les actions sensibles
  const deleteButtons = document.querySelectorAll('.btn-delete');
  
  deleteButtons.forEach(bouton => {
    bouton.addEventListener('click', function(e) {
      if (!confirm('Êtes-vous sûr de vouloir effectuer cette action ?')) {
        e.preventDefault();
      }
    });
  });

  // Gestion des messages flash
  const alerts = document.querySelectorAll('.alert');
  alerts.forEach(alerte => {
    setTimeout(() => {
      alerte.style.opacity = '0';
      setTimeout(() => alerte.remove(), 500);
    }, 5000);
  });
});