<?php
if (!isset($activePage)) {
    $activePage = '';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>E-Tontine - <?= $page_title ?? 'Gestion des tontines' ?></title>

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f7f9fc;
    }

    header {
      background: linear-gradient(to right, #007BFF, #00BFFF);
      padding: 20px 0;
      color: white;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    .container {
      max-width: 1200px;
      margin: auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      padding: 0 30px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo img {
      max-height: 40px;
    }

    .logo h1 {
      margin: 0;
      font-size: 24px;
      font-weight: bold;
      color: white;
    }

    nav {
      display: flex;
      gap: 15px;
      flex-wrap: wrap;
    }

    nav a {
      text-decoration: none;
      color: white;
      padding: 8px 14px;
      border-radius: 5px;
      font-weight: 500;
      transition: background 0.3s ease;
    }

    nav a:hover {
      background-color: rgba(255,255,255,0.2);
    }

    nav a.active {
      background-color: white;
      color: #007BFF;
      font-weight: bold;
    }

    @media screen and (max-width: 768px) {
      .container {
        flex-direction: column;
        align-items: flex-start;
      }
      nav {
        margin-top: 15px;
      }
    }
  </style>
</head>
<body>
  <header>
    <div class="container">
      <div class="logo">
        <img src="assets/img/logo.png" alt="E-Tontine">
        <h1>E-Tontine</h1>
      </div>
      <nav>
        <?php if (function_exists('isLoggedIn') && isLoggedIn()): ?>
          <a href="../pages/dashboard.php" class="<?= ($activePage === 'dashboard') ? 'active' : '' ?>">🏠 Tableau de bord</a>
          <a href="../pages/tontines.php" class="<?= ($activePage === 'tontines') ? 'active' : '' ?>">📁 Mes Tontines</a>
          <a href="../pages/membres.php" class="<?= ($activePage === 'membres') ? 'active' : '' ?>">👥 Membres</a>
          <a href="../includes/logout.php" style="background-color: #dc3545;">🔓 Déconnexion</a>
        <?php else: ?>
          <a href="pages/auth/login.php" class="<?= ($activePage === 'login') ? 'active' : '' ?>">🔐 Connexion</a>
          <a href="pages/auth/register.php" class="<?= ($activePage === 'register') ? 'active' : '' ?>">📝 Inscription</a>
        <?php endif; ?>
      </nav>
    </div>
  </header>