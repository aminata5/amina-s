<?php
require_once 'config.php';
require_once 'auth.php';

/**
 * Vérifie si l'utilisateur est connecté
 */
if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
}

/**
 * Vérifie les credentials et connecte l'utilisateur
 */
function loginUser($email, $password) {
    global $db;

    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Mettre à jour la session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nom'] = $user['nom'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'] ?? 'membre';

            return true;
        }
        return false;
    } catch (PDOException $e) {
        error_log("Erreur de connexion: " . $e->getMessage());
        return false;
    }
}

/**
 * Enregistre un nouvel utilisateur
 */
function registerUser($nom, $email, $telephone, $password) {
    global $db;

    try {
        // Vérifier si l'email existe déjà
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            throw new Exception("Un compte existe déjà avec cet email");
        }

        // Hasher le mot de passe
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insérer le nouvel utilisateur
        $stmt = $db->prepare("INSERT INTO users (nom, email, telephone, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nom, $email, $telephone, $hashedPassword]);

        return $db->lastInsertId();
    } catch (PDOException $e) {
        error_log("Erreur d'inscription: " . $e->getMessage());
        throw new Exception("Erreur lors de la création du compte");
    }
}

/**
 * Déconnecte l'utilisateur
 */
function logoutUser() {
    $_SESSION = array();

    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    session_destroy();
}

/**
 * Vérifie les permissions de l'utilisateur
 */
function hasPermission($requiredRole) {
    if (!isLoggedIn()) {
        return false;
    }

    $userRole = $_SESSION['user_role'] ?? 'membre';

    // Hiérarchie des rôles
    $rolesHierarchy = [
        'admin' => 3,
        'moderateur' => 2,
        'membre' => 1
    ];

    return ($rolesHierarchy[$userRole] >= $rolesHierarchy[$requiredRole]);
}

/**
 * Génère un token CSRF
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Valide un token CSRF
 */
function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}