    </main>

    <footer style="background: #007BFF; color: white; padding: 25px 0; margin-top: 40px;">
        <div class="container" style="max-width: 1200px; margin: auto; text-align: center;">
            <p style="margin: 0; font-size: 15px;">
                &copy; <?= date('Y') ?> <strong>E-Tontine</strong> — Tous droits réservés 🔐
            </p>
            <p style="font-size: 13px; margin-top: 8px;">
                <a href="../pages/cgu.php" style="color:white; text-decoration: underline;">Conditions d’utilisation</a>
                &nbsp;|&nbsp;
                <a href="../pages/confidentialite.php" style="color:white; text-decoration: underline;">Politique de confidentialité</a>
                &nbsp;|&nbsp;
                <a href="https://facebook.com" target="_blank" style="color:white; text-decoration: underline;">Facebook</a>
                &nbsp;|&nbsp;
                <a href="https://twitter.com" target="_blank" style="color:white; text-decoration: underline;">Twitter</a>
            </p>
        </div>
    </footer>

    <script src="../assets/js/script.js"></script>
  </body>
</html>