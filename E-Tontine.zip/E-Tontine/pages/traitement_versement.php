<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect('auth/login.php');
}

// Vérification des données du formulaire
$nom             = $_POST['nom'] ?? null;
$tontine_id      = $_POST['tontine_id'] ?? null;
$montant         = $_POST['montant'] ?? null;
$type_versement  = $_POST['type_versement'] ?? null;
$user_id         = $_SESSION['user_id'] ?? null;

if ($nom && $tontine_id && $montant && $type_versement && $user_id) {
    // Enregistrement dans la base de données
    $stmt = $db->prepare("
        INSERT INTO versements (user_id, nom, tontine_id, montant, type_versement, date)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$user_id, $nom, $tontine_id, $montant, $type_versement]);

    // Redirection après enregistrement
    header("Location: confirmation_versement.php");
    exit();
} else {
    echo "<p style='color:red; font-family:Segoe UI; padding:40px; text-align:center;'>Erreur : certaines données sont manquantes ou invalides.</p>";
}
?>