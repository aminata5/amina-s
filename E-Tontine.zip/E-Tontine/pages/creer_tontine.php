<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect('auth/login.php');
}

$page_title = "Créer une Tontine";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = sanitize($_POST['nom']);
    $description = sanitize($_POST['description']);
    $montant = (float)$_POST['montant'];
    $frequence = sanitize($_POST['frequence']);
    $date_debut = $_POST['date_debut'];

    try {
        $stmt = $db->prepare("INSERT INTO tontines (nom, description, montant, frequence, date_debut, createur_id) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nom, $description, $montant, $frequence, $date_debut, $_SESSION['user_id']]);

        $_SESSION['success'] = "✅ Tontine créée avec succès !";
        redirect('dashboard.php');
    } catch (PDOException $e) {
        $_SESSION['error'] = "❌ Erreur : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $page_title ?></title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f7f9fc;
            padding: 40px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 8px rgba(0,0,0,0.05);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
            color: #007BFF;
        }

        input, textarea, select {
            width: 100%;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        button.btn {
            background-color: #28a745;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }

        button.btn:hover {
            background-color: #218838;
        }

        .preview {
            max-width: 600px;
            margin: 20px auto;
            padding: 15px;
            background: #e9f7ef;
            border-left: 5px solid #28a745;
            border-radius: 5px;
        }

        .alert {
            max-width: 600px;
            margin: 20px auto;
            padding: 15px;
            border-radius: 6px;
            text-align: center;
        }

        .alert.error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>

    <script>
        function updatePreview() {
            const nom = document.querySelector('[name=nom]').value;
            const montant = document.querySelector('[name=montant]').value;
            const frequence = document.querySelector('[name=frequence]').value;
            const date = document.querySelector('[name=date_debut]').value;

            document.getElementById('previewContent').innerText =
                `Nom: ${nom}\nMontant: ${montant} FCFA\nFréquence: ${frequence}\nDémarrage: ${date}`;
        }
    </script>
</head>
<body>

    <h2>📝 Créer une nouvelle tontine</h2>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="POST" oninput="updatePreview()">
        <div class="form-group">
            <label>Nom de la tontine</label>
            <input type="text" name="nom" required>
        </div>

        <div class="form-group">
            <label>Description</label>
            <textarea name="description" rows="3"></textarea>
        </div>

        <div class="form-group">
            <label>Montant de la cotisation (FCFA)</label>
            <input type="number" name="montant" min="0" step="0.01" required>
        </div>

        <div class="form-group">
            <label>Fréquence de cotisation</label>
            <select name="frequence" required>
                <option value="quotidien">Quotidienne</option>
                <option value="hebdomadaire">Hebdomadaire</option>
                <option value="mensuel" selected>Mensuelle</option>
            </select>
        </div>

        <div class="form-group">
            <label>Date de démarrage</label>
            <input type="date" name="date_debut" required>
        </div>

        <button type="submit" class="btn">➕ Créer la tontine</button>
    </form>

    <div class="preview">
        <h3>🎯 Aperçu de votre tontine</h3>
        <pre id="previewContent">Remplissez les champs pour voir l'aperçu ici...</pre>
    </div>

</body>
</html>