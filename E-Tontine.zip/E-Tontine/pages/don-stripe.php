<?php
require_once '../vendor/autoload.php';
\Stripe\Stripe::setApiKey('sk_test_51RjQTrCoiroIUM078fHkHsmgJRW6G00GCpu4CfuHo4oV1ddb60o8msyrVwSPpUv2hbkPkC31qvHMFMlpVUW2m8Fa00Uq4AFohb'); // ta clé secrète Stripe

$montant_fcfa = intval($_POST['montant'] ?? 0);
$nom_donneur = $_POST['nom'] ?? 'Visiteur';

$session = \Stripe\Checkout\Session::create([
  'payment_method_types' => ['card'],
  'line_items' => [[
    'price_data' => [
      'currency' => 'xof',
      'product_data' => ['name' => 'Don E-Tontine'],
      'unit_amount' => $montant_fcfa * 100, // Stripe attend les montants en centimes
    ],
    'quantity' => 1,
  ]],
  'mode' => 'payment',
  'success_url' => 'http://localhost/pages/success.php?nom=' . urlencode($nom_donneur),
  'cancel_url' => 'http://localhost/pages/don.php',
]);

header("Location: " . $session->url);
exit;