<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect('auth/login.php');
}

$page_title = "Faire un versement";
$user_id = $_SESSION['user_id'];

// Récupération du nom de l'utilisateur
$nom_utilisateur = "Nom inconnu";
$stmtNom = $db->prepare("SELECT nom FROM users WHERE id = ?");
$stmtNom->execute([$user_id]);
if ($result = $stmtNom->fetch()) {
    $nom_utilisateur = $result['nom'];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title><?= $page_title ?></title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f2f4f8;
      padding: 40px;
    }
    .form-container {
      max-width: 500px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.06);
    }
    h2 {
      text-align: center;
      color: #28a745;
      margin-bottom: 25px;
    }
    label {
      display: block;
      margin-bottom: 6px;
      font-weight: bold;
    }
    select, input[type="number"], input[type="text"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 16px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    input[readonly] {
      background-color: #e9ecef;
    }
    button {
      background-color: #007BFF;
      color: white;
      padding: 12px;
      width: 100%;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
    }
    button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>

<div class="form-container">
  <h2>💸 Faire un versement</h2>
  <form method="POST" action="traitement_versement.php">
    <!-- Nom utilisateur -->
    <label for="nom">Nom :</label>
    <input type="text" name="nom" id="nom" value="<?= htmlspecialchars($nom_utilisateur) ?>" readonly>

    <!-- Tontine -->
    <label for="tontine">Tontine :</label>
    <select name="tontine_id" id="tontine" required>
      <?php
      $stmt = $db->query("SELECT id, nom FROM tontines");
      while ($row = $stmt->fetch()) {
          echo "<option value=\"{$row['id']}\">{$row['nom']}</option>";
      }
      ?>
    </select>

    <!-- Montant -->
    <label for="montant">Montant (FCFA) :</label>
    <input type="number" name="montant" id="montant" required min="100">

    <!-- Type de versement -->
    <label for="type">Type de versement :</label>
    <select name="type_versement" id="type" required>
      <option value="">-- Choisir --</option>
      <option value="mensuel">Mensuel</option>
      <option value="exceptionnel">Exceptionnel</option>
      <option value="retard">Retard</option>
    </select>

    <button type="submit">Confirmer le versement</button>
  </form>
</div>

</body>
</html>