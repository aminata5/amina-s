<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!isLoggedIn()) {
    redirect('pages/auth/login.php');
}

$page_title = "Gestion des Membres";

$search = $_GET['search'] ?? '';
$search_query = '%' . $search . '%';

try {
    $stmt = $db->prepare("
        SELECT id, nom, email, telephone, created_at, role 
        FROM users 
        WHERE id != ? AND (nom LIKE ? OR role LIKE ?) 
        ORDER BY nom ASC
    ");
    $stmt->execute([$_SESSION['user_id'], $search_query, $search_query]);
    $members = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = "Erreur lors de la récupération des membres: " . $e->getMessage();
    $members = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['user_id'])) {
    if (!validateCSRFToken($_POST['csrf_token'])) {
        $_SESSION['error'] = "Token de sécurité invalide";
        redirect('members.php');
    }

    $user_id = (int)$_POST['user_id'];
    $action = $_POST['action'];

    try {
        switch ($action) {
            case 'promote':
                $db->prepare("UPDATE users SET role = 'moderateur' WHERE id = ?")->execute([$user_id]);
                $_SESSION['success'] = "Membre promu modérateur";
                break;
            case 'demote':
                $db->prepare("UPDATE users SET role = 'membre' WHERE id = ?")->execute([$user_id]);
                $_SESSION['success'] = "Modérateur rétrogradé";
                break;
            case 'delete':
                $stmt = $db->prepare("SELECT COUNT(*) FROM tontines WHERE createur_id = ?");
                $stmt->execute([$user_id]);
                if ($stmt->fetchColumn() > 0) {
                    $_SESSION['error'] = "Impossible de supprimer un créateur de tontine";
                } else {
                    $db->prepare("DELETE FROM membres_tontine WHERE user_id = ?")->execute([$user_id]);
                    $db->prepare("DELETE FROM users WHERE id = ?")->execute([$user_id]);
                    $_SESSION['success'] = "Membre supprimé";
                }
                break;
            default:
                $_SESSION['error'] = "Action non reconnue";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur : " . $e->getMessage();
    }

    redirect('members.php');
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $page_title ?></title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f7fa;
            padding: 40px;
        }

        h2 {
            text-align: center;
            color: #007BFF;
        }

        .alert {
            max-width: 800px;
            margin: 20px auto;
            padding: 12px;
            border-radius: 6px;
            font-weight: bold;
            text-align: center;
        }

        .alert.error {
            background-color: #f8d7da;
            color: #721c24;
        }

        .alert.success {
            background-color: #d4edda;
            color: #155724;
        }

        .stats {
            max-width: 1000px;
            margin: 0 auto 20px auto;
            display: flex;
            justify-content: space-between;
            font-weight: bold;
            color: #333;
        }

        .search-bar {
            max-width: 800px;
            margin: 0 auto 20px auto;
            text-align: center;
        }

        .search-bar input {
            padding: 8px 12px;
            font-size: 14px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 60%;
            max-width: 400px;
        }

        .search-bar button {
            padding: 8px 14px;
            font-size: 14px;
            margin-left: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007BFF;
            color: white;
            cursor: pointer;
        }

        table {
            width: 100%;
            max-width: 1000px;
            margin: auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 0 8px rgba(0,0,0,0.05);
        }

        th, td {
            padding: 12px;
            border: 1px solid #dee2e6;
            font-size: 14px;
            text-align: left;
        }

        thead {
            background-color: #e9ecef;
        }

        .actions {
            text-align: center;
        }

        .btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 7px 11px;
            margin: 2px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 13px;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .role-icon {
            font-weight: bold;
        }

        .moderateur {
            color: #17a2b8;
        }

        .membre {
            color: #28a745;
        }

        @media screen and (max-width: 768px) {
            body { padding: 20px; }
            th, td { font-size: 12px; }
            .btn { font-size: 12px; padding: 6px 8px; }
        }
    </style>
</head>
<body>

<h2>🔧 Gestion des Membres</h2>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<?php if (isset($_SESSION['success'])): ?>
    <div class="alert success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>

<div class="stats">
    <div>👥 Total : <?= count($members) ?> membres</div>
    <div>🧑‍🏫 Modérateurs : <?= count(array_filter($members, fn($m) => $m['role'] === 'moderateur')) ?></div>
</div>

<div class="search-bar">
    <form method="GET">
        <input type="text" name="search" placeholder="🔍 Rechercher par nom ou rôle" value="<?= htmlspecialchars($search) ?>">
        <button type="submit">Filtrer</button>
    </form>
</div>

<table>
    <thead>
    <tr>
        <th>Nom</th>
        <th>Email</th>
        <th>Téléphone</th>
        <th>Inscrit le</th>
        <th>Rôle</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($members as $member): ?>
        <tr>
            <td><?= htmlspecialchars($member['nom']) ?></td>
            <td><?= htmlspecialchars($member['email']) ?></td>
            <td><?= htmlspecialchars($member['telephone']) ?></td>
            <td><?= date('d/m/Y', strtotime($member['created_at'])) ?></td>
            <td><span class="role-icon <?= $member['role'] ?>"><?= ucfirst($member['role'] ?? 'membre') ?></span></td>
            <td class="actions">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                    <input type="hidden" name="user_id" value="<?= $member['id'] ?>">
                    <?php if ($member['role'] === 'membre'): ?>
                        <button type="submit" name="action" value="promote" class="btn">Promouvoir</button>
                    <?php elseif ($member['role'] === 'moderateur'): ?>
                        <button type="submit" name="action" value="demote" class="btn">Rétrograder</button>
                    <?php endif; ?>
                    <button type="submit" name="action" value="delete" class="btn btn-danger"
                            onclick="return confirm('Confirmer la suppression de ce membre ?')">
                        Supprimer
                    </button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>