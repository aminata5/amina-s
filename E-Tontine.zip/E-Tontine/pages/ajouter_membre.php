<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect('auth/login.php');
}

if (!isset($_GET['tontine_id'])) {
    redirect('tontines.php');
}

$tontine_id = (int)$_GET['tontine_id'];

// Vérifier que l'utilisateur est le créateur
$stmt = $db->prepare("SELECT 1 FROM tontines WHERE id = ? AND createur_id = ?");
$stmt->execute([$tontine_id, $_SESSION['user_id']]);
$is_creator = $stmt->fetch();

if (!$is_creator) {
    $_SESSION['error'] = "Action non autorisée";
    redirect('tontines.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);
    $cin = sanitize($_POST['cin']);
    $file_name = null;

    // Gestion du fichier CIN
    if (!empty($_FILES['cin_file']['name']) && $_FILES['cin_file']['error'] === UPLOAD_ERR_OK) {
        $tmp = $_FILES['cin_file']['tmp_name'];
        $original = basename($_FILES['cin_file']['name']);
        $file_name = uniqid('cin_') . '_' . $original;
        $destination = '../uploads/cin/' . $file_name;
        move_uploaded_file($tmp, $destination);
    }

    // Vérifier si utilisateur existe
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        $_SESSION['error'] = "Aucun utilisateur trouvé avec cet email";
    } else {
        // Vérifier s’il est déjà membre
        $stmt = $db->prepare("SELECT 1 FROM membres_tontine WHERE tontine_id = ? AND user_id = ?");
        $stmt->execute([$tontine_id, $user['id']]);
        $already_member = $stmt->fetch();

        if ($already_member) {
            $_SESSION['error'] = "Cet utilisateur est déjà membre de la tontine";
        } else {
            try {
                $stmt = $db->prepare("INSERT INTO membres_tontine (tontine_id, user_id, cin_numero, cin_fichier) VALUES (?, ?, ?, ?)");
                $stmt->execute([$tontine_id, $user['id'], $cin, $file_name]);

                $_SESSION['success'] = "Membre ajouté avec succès";
                redirect("dashboard.php");
            } catch(PDOException $e) {
                $_SESSION['error'] = "Erreur: " . $e->getMessage();
            }
        }
    }
}

$page_title = "Ajouter un membre";
include '../includes/header.php';
?>

<style>
    .form-container {
        max-width: 600px;
        margin: 30px auto;
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.06);
    }

    .form-container h2 {
        text-align: center;
        color: #007BFF;
        margin-bottom: 25px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    label {
        font-weight: bold;
        display: block;
        margin-bottom: 6px;
        color: #444;
    }

    input[type="email"],
    input[type="text"],
    input[type="file"] {
        width: 100%;
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
    }

    .btn {
        background-color: #28a745;
        color: white;
        padding: 10px 16px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        margin-right: 10px;
    }

    .btn.cancel {
        background-color: #dc3545;
    }

    .alert {
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 20px;
        text-align: center;
        font-weight: bold;
    }

    .alert.error {
        background-color: #f8d7da;
        color: #721c24;
    }

    .alert.success {
        background-color: #d4edda;
        color: #155724;
    }
</style>

<div class="form-container">
    <h2>➕ Ajouter un membre à la tontine</h2>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="email">Adresse Email du membre</label>
            <input type="email" name="email" id="email" required>
        </div>

        <div class="form-group">
            <label for="cin">Numéro de carte d'identité nationale</label>
            <input type="text" name="cin" id="cin" required>
        </div>

        <div class="form-group">
            <label for="cin_file">📄 Fichier CIN (PNG, JPG, PDF)</label>
            <input type="file" name="cin_file" id="cin_file" accept=".jpg,.jpeg,.png,.pdf">
        </div>

        <button type="submit" class="btn">Ajouter</button>
        <a href="tontine_details.php?id=<?= $tontine_id ?>" class="btn cancel">Annuler</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>