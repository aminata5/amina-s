<?php
require_once '../includes/config.php';
$page_title = "Faire un don - E-Tontine";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $montant = floatval($_POST['montant'] ?? 0);
    $message = trim($_POST['message'] ?? '');

    if ($nom && $montant > 0) {
        // Enregistrement fictif, à adapter à ta table "dons"
        $stmt = $db->prepare("INSERT INTO dons (nom, montant, message, date_don) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$nom, $montant, $message]);
        $success = true;
    } else {
        $error = "Veuillez renseigner votre nom et un montant valide.";
    }
}
?>

<?php include '../includes/header.php'; ?>

<style>
.don-form {
  max-width: 600px;
  margin: 60px auto;
  background: #fff;
  padding: 40px;
  border-radius: 10px;
  box-shadow: 0 0 8px rgba(0,0,0,0.1);
}
.don-form h2 {
  text-align: center;
  color: #007bff;
  margin-bottom: 30px;
}
.don-form label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
}
.don-form input, .don-form textarea {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border-radius: 6px;
  border: 1px solid #ccc;
}
.don-form button {
  background: #007bff;
  color: white;
  font-weight: bold;
  padding: 12px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  width: 100%;
}
.don-form button:hover {
  background: #0056b3;
}
.success-message, .error-message {
  background: #eaf9ea;
  color: #2e7d32;
  padding: 10px;
  border-radius: 6px;
  margin-bottom: 20px;
  text-align: center;
}
.error-message {
  background: #fbeaea;
  color: #d32f2f;
}
</style>

<div class="don-form">
  <h2>🎁 Faire un don libre</h2>

  <?php if (!empty($success)): ?>
    <div class="success-message">Merci pour votre contribution 💙</div>
  <?php elseif (!empty($error)): ?>
    <div class="error-message"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form action="don-stripe.php" method="POST">
    <input type="hidden" name="nom" value="NomVisiteur">
    <input type="hidden" name="montant" value="5000"> <!-- en FCFA -->
    <button type="submit" style="background:#007bff; color:white; padding:12px 24px; border:none; border-radius:6px;">
        Faire un don sécurisé
    </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>