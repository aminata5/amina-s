<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect('auth/login.php');
}

$page_title = "Confirmation du versement";
$user_id = $_SESSION['user_id'];

// Récupération du dernier versement
$stmt = $db->prepare("
    SELECT v.nom, t.nom AS tontine, v.montant, v.type_versement, DATE_FORMAT(v.date, '%d/%m/%Y à %Hh%i') AS date_versement
    FROM versements v
    JOIN tontines t ON v.tontine_id = t.id
    WHERE v.user_id = ?
    ORDER BY v.id DESC
    LIMIT 1
");
$stmt->execute([$user_id]);
$versement = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title><?= $page_title ?></title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #eef2f7;
      padding: 60px;
      text-align: center;
    }
    .confirmation-box {
      background: white;
      padding: 30px;
      border-radius: 10px;
      max-width: 500px;
      margin: auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
      color: #28a745;
      margin-bottom: 20px;
    }
    p {
      font-size: 16px;
      margin: 8px 0;
    }
    .btn {
      margin-top: 25px;
      display: inline-block;
      background-color: #007BFF;
      color: white;
      padding: 10px 20px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
    }
    .btn:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>

<div class="confirmation-box">
  <h2>✅ Versement enregistré avec succès</h2>

  <?php if ($versement): ?>
    <p><strong>Nom :</strong> <?= htmlspecialchars($versement['nom']) ?></p>
    <p><strong>Tontine :</strong> <?= htmlspecialchars($versement['tontine']) ?></p>
    <p><strong>Montant :</strong> <?= number_format($versement['montant'], 0, ',', ' ') ?> FCFA</p>
    <p><strong>Type :</strong> <?= ucfirst($versement['type_versement']) ?></p>
    <p><strong>Date :</strong> <?= $versement['date_versement'] ?></p>
  <?php else: ?>
    <p>Aucun versement récent trouvé.</p>
  <?php endif; ?>

  <a href="dashboard.php" class="btn">Retour au tableau de bord</a>
</div>

</body>
</html>