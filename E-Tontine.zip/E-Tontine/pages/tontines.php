<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect('auth/login.php');
}

$page_title = "Mes Tontines";

// Paramètres de filtre
$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'created_at';

// Requête de tontines avec filtre
$stmt = $db->prepare("
    SELECT t.*, u.nom as createur_nom 
    FROM tontines t
    JOIN users u ON t.createur_id = u.id
    LEFT JOIN membres_tontine mt ON t.id = mt.tontine_id
    WHERE (t.createur_id = :uid OR mt.user_id = :uid)
    AND t.nom LIKE :search
    ORDER BY t.$sort DESC
");
$stmt->execute([
    'uid' => $_SESSION['user_id'],
    'search' => "%$search%"
]);
$tontines = $stmt->fetchAll();

// Requête pour le graphique
$frequence_stats = $db->prepare("
    SELECT frequence, COUNT(*) as total
    FROM tontines
    WHERE createur_id = ?
    GROUP BY frequence
");
$frequence_stats->execute([$_SESSION['user_id']]);
$frequence_data = $frequence_stats->fetchAll();

$labels = [];
$totaux = [];
foreach ($frequence_data as $row) {
    $labels[] = ucfirst($row['frequence']);
    $totaux[] = $row['total'];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $page_title ?></title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f7fa;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 15px;
        }

        form {
            text-align: center;
            margin-bottom: 25px;
        }

        input[type="text"], select {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-right: 10px;
            font-size: 14px;
        }

        button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        a.btn {
            display: inline-block;
            background-color: #28a745;
            color: white;
            padding: 10px 16px;
            border-radius: 5px;
            text-decoration: none;
            margin-bottom: 20px;
            transition: background 0.3s ease;
        }

        a.btn:hover {
            background-color: #218838;
        }

        .tontines-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .tontine-card {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
            transition: transform 0.2s ease;
        }

        .tontine-card:hover {
            transform: translateY(-4px);
        }

        .tontine-card h3 {
            margin: 0;
            color: #007BFF;
        }

        .tontine-card p {
            margin: 6px 0;
            color: #555;
        }

        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            color: white;
            font-size: 13px;
        }

        .badge.actif { background-color: #28a745; }
        .badge.termine { background-color: #dc3545; }
        .badge.attente { background-color: #ffc107; }

        .actions {
            margin-top: 12px;
        }

        .actions a {
            margin-right: 10px;
        }

        canvas {
            max-width: 400px;
            margin: 30px auto 40px auto;
            display: block;
        }
    </style>
</head>
<body>

    <h2>📁 Mes Tontines</h2>

    <form method="GET">
        <input type="text" name="search" placeholder="🔍 Rechercher une tontine" value="<?= htmlspecialchars($search) ?>">
        <select name="sort">
            <option value="created_at" <?= ($sort === 'created_at') ? 'selected' : '' ?>>📅 Date</option>
            <option value="montant" <?= ($sort === 'montant') ? 'selected' : '' ?>>💰 Montant</option>
            <option value="frequence" <?= ($sort === 'frequence') ? 'selected' : '' ?>>📆 Fréquence</option>
        </select>
        <button type="submit">Filtrer</button>
    </form>

    <div style="text-align: center;">
        <a href="creer_tontine.php" class="btn">➕ Créer une nouvelle tontine</a>
    </div>

    <h3 style="text-align:center;">📊 Répartition des tontines par fréquence</h3>
    <canvas id="frequenceChart"></canvas>

    <script>
    const ctx = document.getElementById('frequenceChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($labels) ?>,
            datasets: [{
                data: <?= json_encode($totaux) ?>,
                backgroundColor: ['#007bff','#ffc107','#28a745'],
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
    </script>

    <div class="tontines-list">
        <?php foreach ($tontines as $tontine): ?>
            <?php
                $status = $tontine['statut'] ?? 'actif';
                $badgeClass = match($status) {
                    'actif' => 'actif',
                    'termine' => 'termine',
                    'attente' => 'attente',
                    default => 'actif'
                };
            ?>
            <div class="tontine-card">
                <h3><?= htmlspecialchars($tontine['nom']) ?></h3>
                <p>🧑‍💼 Créée par : <?= htmlspecialchars($tontine['createur_nom']) ?></p>
                <p>💰 Montant : <?= number_format($tontine['montant'], 2) ?> FCFA</p>
                <p>📆 Fréquence : <?= ucfirst($tontine['frequence']) ?></p>
                <p>🗓 Date création : <?= date('d/m/Y', strtotime($tontine['created_at'])) ?></p>
                <p><span class="badge <?= $badgeClass ?>"><?= ucfirst($status) ?></span></p>

                <div class="actions">
                    <a href="tontine_details.php?id=<?= $tontine['id'] ?>" class="btn">🔎 Détails</a>
                    <?php if ($tontine['createur_id'] == $_SESSION['user_id']): ?>
                        <a href="gerer_tontine.php?id=<?= $tontine['id'] ?>" class="btn">⚙️ Gérer</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

</body>
</html>