<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "ID de tontine invalide.";
    exit();
}

$tontine_id = intval($_GET['id']);

// Récupération de la tontine
$stmt = $db->prepare("SELECT * FROM tontines WHERE id = ?");
$stmt->execute([$tontine_id]);
$tontine = $stmt->fetch();

if (!$tontine) {
    echo "Tontine introuvable.";
    exit();
}

// Membres
$stmt = $db->prepare("
    SELECT u.nom, u.email 
    FROM membres_tontine mt 
    JOIN users u ON mt.user_id = u.id 
    WHERE mt.tontine_id = ?
");
$stmt->execute([$tontine_id]);
$membres = $stmt->fetchAll();

// Versements
$stmt = $db->prepare("
    SELECT v.montant, v.date, u.nom as membre_nom 
    FROM versements v 
    JOIN users u ON v.user_id = u.id 
    WHERE v.tontine_id = ? 
    ORDER BY v.date DESC
");
$stmt->execute([$tontine_id]);
$versements = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gérer la tontine</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f4f8;
            margin: 0;
            padding: 30px;
        }

        h1, h2 {
            text-align: center;
            color: #333;
        }

        .details {
            max-width: 800px;
            margin: 0 auto 30px auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0,0,0,0.05);
        }

        .details li {
            margin: 10px 0;
            list-style: none;
            color: #555;
        }

        .members-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .member-card {
            background: white;
            padding: 16px;
            border-radius: 8px;
            box-shadow: 0 0 6px rgba(0,0,0,0.05);
        }

        .member-card h4 {
            margin: 0 0 8px 0;
            color: #28a745;
        }

        .member-card p {
            margin: 4px 0;
            color: #555;
        }

        table {
            width: 100%;
            max-width: 900px;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 6px rgba(0,0,0,0.05);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
            font-size: 14px;
        }

        th {
            background-color: #e9ecef;
        }

        .actions {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            margin-top: 40px;
        }

        .btn {
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 6px;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h1>👥 Gérer la tontine : <?= htmlspecialchars($tontine['nom']) ?></h1>

    <ul class="details">
        <li>💰 Montant : <?= number_format($tontine['montant'], 2) ?> FCFA</li>
        <li>📅 Début : <?= date('d/m/Y', strtotime($tontine['date_debut'])) ?></li>
        <li>🔄 Nombre de tours : <?= htmlspecialchars($tontine['nb_tours'] ?? '—') ?></li>
    </ul>

    <h2>🧍 Membres</h2>
    <div class="members-list">
        <?php foreach ($membres as $membre): ?>
            <div class="member-card">
                <h4><?= htmlspecialchars($membre['nom']) ?></h4>
                <p>Email : <?= htmlspecialchars($membre['email']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>

    <h2>📋 Versements</h2>
    <table>
        <tr>
            <th>Membre</th>
            <th>Montant</th>
            <th>Date</th>
        </tr>
        <?php foreach ($versements as $v): ?>
            <tr>
                <td><?= htmlspecialchars($v['membre_nom']) ?></td>
                <td><?= number_format($v['montant'], 2) ?> FCFA</td>
                <td><?= date('d/m/Y', strtotime($v['date'])) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div class="actions">
        <a href="modifier_tontine.php?id=<?= $tontine_id ?>" class="btn">🛠 Modifier la tontine</a>
        <a href="supprimer_tontine.php?id=<?= $tontine_id ?>" class="btn" onclick="return confirm('Confirmer la suppression ?');">❌ Supprimer</a>
        <a href="ajouter_versement.php?id=<?= $tontine_id ?>" class="btn">➕ Ajouter un versement</a>
        <a href="liste_tours.php?id=<?= $tontine_id ?>" class="btn">🔁 Voir les tours</a>
    </div>

</body>
</html>