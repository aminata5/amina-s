<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    header("Location: ../auth/login.php");
    exit();
}

$page_title = "Tableau de Bord";
$user_id = $_SESSION['user_id'];

// Statistiques personnelles
$stmt = $db->prepare("SELECT COUNT(*) FROM tontines WHERE createur_id = ?");
$stmt->execute([$user_id]);
$tontines_created = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM membres_tontine WHERE user_id = ?");
$stmt->execute([$user_id]);
$tontines_joined = $stmt->fetchColumn();

// Informations utilisateur
$stmt = $db->prepare("SELECT nom, email, telephone FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user_data = $stmt->fetch();

// Statistiques globales
$nb_users      = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$nb_members    = $db->query("SELECT COUNT(*) FROM membres_tontine")->fetchColumn();
$nb_versements = $db->query("SELECT COUNT(*) FROM versements")->fetchColumn();
$nb_tontines   = $db->query("SELECT COUNT(*) FROM tontines")->fetchColumn();

// Statistique : Tontines à venir
$stmt = $db->prepare("SELECT COUNT(*) FROM tontines WHERE date_debut >= CURDATE() AND createur_id = ?");
$stmt->execute([$user_id]);
$tontines_a_venir = $stmt->fetchColumn();

// Statistique : Total montant versé
$montant_total = $db->query("SELECT SUM(montant) FROM versements")->fetchColumn();

// Liste des prochaines tontines
$stmt = $db->prepare("SELECT nom, date_debut FROM tontines WHERE createur_id = ? AND date_debut >= CURDATE() ORDER BY date_debut ASC LIMIT 5");
$stmt->execute([$user_id]);
$next_tontines = $stmt->fetchAll();

// Fréquence des tontines (graphiques)
$stmt = $db->prepare("SELECT frequence, COUNT(*) as total FROM tontines WHERE createur_id = ? GROUP BY frequence");
$stmt->execute([$user_id]);
$freq_data = $stmt->fetchAll();

$freq_labels = [];
$freq_counts = [];
foreach ($freq_data as $row) {
    $freq_labels[] = ucfirst($row['frequence']);
    $freq_counts[] = $row['total'];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $page_title ?></title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #eef2f7;
            margin: 0;
            padding: 40px;
        }

        .welcome-title {
            font-size: 36px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 40px;
            padding: 20px;
            border-radius: 12px;
            background: linear-gradient(90deg, #e3f2fd, #f1f8e9);
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            color: #007BFF;
            position: relative;
        }

        .welcome-title::after {
            content: '🌟';
            position: absolute;
            right: 30px;
            top: 20px;
            font-size: 24px;
            opacity: 0.5;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
            max-width: 1200px;
            margin: auto;
        }

        .left-panel, .right-panel {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }

        .profile-box h3 {
            margin-top: 0;
            color: #007BFF;
        }

        .profile-box p {
            margin: 8px 0;
            font-size: 15px;
            color: #444;
        }

        .action-buttons {
            margin-top: 25px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .action-buttons a {
            background-color: #28a745;
            color: white;
            text-align: center;
            padding: 10px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }

        .action-buttons a:hover {
            background-color: #218838;
        }

        .settings-form {
            margin-top: 30px;
        }

        .settings-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 12px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .settings-form button {
            background-color: #007BFF;
            color: white;
            padding: 10px 16px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }

        .settings-form button:hover {
            background-color: #0056b3;
        }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        .stat-card {
            background: #f9fbfd;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            box-shadow: inset 0 0 5px rgba(0,0,0,0.03);
        }

        .stat-card h4 {
            margin: 0;
            color: #555;
        }

        .stat-card p {
            font-size: 22px;
            color: #007BFF;
            margin: 6px 0 0;
            font-weight: bold;
        }

        .upcoming-box {
            margin-top: 30px;
        }

        .upcoming-box h3 {
            color: #007BFF;
        }

        .upcoming-box ul {
            list-style: none;
            padding: 0;
        }

        .upcoming-box li {
            background: #f4f9ff;
            padding: 8px 12px;
            margin: 6px 0;
            border-left: 4px solid #007BFF;
            border-radius: 4px;
        }

        canvas {
            max-width: 480px;
            margin: 30px auto;
            display: block;
        }

        @media screen and (max-width: 900px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <h1 class="welcome-title">👋 Bienvenue, <?= htmlspecialchars($_SESSION['user_nom']) ?></h1>

    <div class="dashboard-grid">
        <!-- Left panel -->
        <div class="left-panel">
            <div class="profile-box">
                <h3>📇 Informations</h3>
                <p><strong>Nom :</strong> <?= htmlspecialchars($user_data['nom']) ?></p>
                <p><strong>Email :</strong> <?= htmlspecialchars($user_data['email']) ?></p>
                <p><strong>Téléphone :</strong> <?= htmlspecialchars($user_data['telephone']) ?></p>
            </div>

            <div class="action-buttons">
                <a href="creer_tontine.php">➕ Créer une tontine</a>
                <a href="tontines.php">📁 Mes tontines</a>
                <a href="members.php">👥 Gérer les membres</a>
                <a href="ajouter_membre.php?tontine_id=1">➕ Ajouter un membre</a>
                <a href="liste_versements.php">📋 Voir les versements</a>
                <a href="../pages/auth/logout.php" onclick="return confirm('Voulez-vous vraiment vous déconnecter ?');" class="logout">🔓 Se déconnecter</a>
            </div>

            <form method="POST" action="update_settings.php" class="settings-form">
                <h3>⚙️ Modifier mes informations</h3>
                <input type="text" name="nom" value="<?= htmlspecialchars($user_data['nom']) ?>" required>
                <input type="email" name="email" value="<?= htmlspecialchars($user_data['email']) ?>" required>
                <input type="text" name="telephone" value="<?= htmlspecialchars($user_data['telephone']) ?>" required>
                <button type="submit">💾 Enregistrer</button>
            </form>

            <div class="upcoming-box">
                <h3>📅 Prochaines tontines</h3>
                <ul>
                    <?php foreach ($next_tontines as $t): ?>
                        <li><strong><?= htmlspecialchars($t['nom']) ?> :</strong> <?= date("d/m/Y", strtotime($t['date_debut'])) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <!-- Right panel -->
        <div class="right-panel">
            <div class="stat-grid">
                <div class="stat-card"><h4>Tontines créées</h4><p><?= $tontines_created ?></p></div>
                <div class="stat-card"><h4>Tontines rejointes</h4><p><?= $tontines_joined ?></p></div>
                <div class="stat-card"><h4>Utilisateurs</h4><p><?= $nb_users ?></p></div>
                <div class="stat-card"><h4>Membres</h4><p><?= $nb_members ?></p></div>
                <div class="stat-card"><h4>Versements</h4><p><?= $nb_versements ?></p></div>
                <div class="stat-card"><h4>Tontines totales</h4><p><?= $nb_tontines ?></p></div>
                <div class="stat-card"><h4>Tontines à venir</h4><p><?= $tontines_a_venir ?></p></div>
                <div class="stat-card"><h4>Total versé</h4><p><?= number_format($montant_total, 0, ',', ' ') ?> CFA</p></div>
            </div>

            <canvas id="frequenceChart"></canvas>
            <script>
            const ctx = document.getElementById('frequenceChart').getContext('2d');
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: <?= json_encode($freq_labels) ?>,
                    datasets: [{
                        data: <?= json_encode($freq_counts) ?>,
                        backgroundColor: ['#007bff','#ffc107','#28a745','#17a2b8'],
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'bottom' }
                    }
                }
            });
            </script>
        </div>
    </div>

</body>
</html>
