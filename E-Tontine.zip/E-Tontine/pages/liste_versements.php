<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect('auth/login.php');
}

$page_title = "Liste des versements";
$user_id = $_SESSION['user_id'];

// Requête pour récupérer les versements de l'utilisateur
$stmt = $db->prepare("
  SELECT v.id, v.nom, t.nom AS tontine, v.montant, v.type_versement, DATE_FORMAT(v.date, '%d/%m/%Y à %Hh%i') AS date_versement
  FROM versements v
  JOIN tontines t ON v.tontine_id = t.id
  WHERE v.user_id = ?
  ORDER BY v.date DESC
");
$stmt->execute([$user_id]);
$versements = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title><?= $page_title ?></title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f8fafc;
      padding: 40px;
    }
    h2 {
      text-align: center;
      color: #007BFF;
      margin-bottom: 20px;
    }
    .actions {
      text-align: center;
      margin-bottom: 30px;
    }
    .btn-ajouter {
      background-color: #28a745;
      color: white;
      padding: 12px 20px;
      text-decoration: none;
      border-radius: 6px;
      font-weight: bold;
      transition: background 0.3s ease;
    }
    .btn-ajouter:hover {
      background-color: #218838;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }
    th, td {
      border: 1px solid #dee2e6;
      padding: 12px;
      text-align: left;
    }
    th {
      background-color: #007BFF;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f2f4f8;
    }
  </style>
</head>
<body>

<h2>📋 Historique de vos versements</h2>

<div class="actions">
  <a href="versements.php" class="btn-ajouter">➕ Ajouter un nouveau versement</a>
</div>

<?php if ($versements): ?>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Nom</th>
        <th>Tontine</th>
        <th>Montant</th>
        <th>Type</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($versements as $v): ?>
        <tr>
          <td><?= $v['id'] ?></td>
          <td><?= htmlspecialchars($v['nom']) ?></td>
          <td><?= htmlspecialchars($v['tontine']) ?></td>
          <td><?= number_format($v['montant'], 0, ',', ' ') ?> FCFA</td>
          <td><?= ucfirst($v['type_versement']) ?></td>
          <td><?= $v['date_versement'] ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php else: ?>
  <p style="text-align:center; font-size:16px;">Aucun versement enregistré pour le moment.</p>
<?php endif; ?>

</body>
</html>