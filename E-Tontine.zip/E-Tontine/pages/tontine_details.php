<?php
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect('auth/login.php');
}

$tontine_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$page_title = "Détails de la Tontine";

// Détails de la tontine
$stmt = $db->prepare("SELECT t.*, u.nom AS createur_nom FROM tontines t JOIN users u ON t.createur_id = u.id WHERE t.id = ?");
$stmt->execute([$tontine_id]);
$tontine = $stmt->fetch();

if (!$tontine) {
    echo "Tontine introuvable.";
    exit;
}

// Membres
$stmt = $db->prepare("SELECT u.nom, u.email, u.telephone FROM membres_tontine mt JOIN users u ON mt.user_id = u.id WHERE mt.tontine_id = ?");
$stmt->execute([$tontine_id]);
$membres = $stmt->fetchAll();

// Versements
$stmt = $db->prepare("SELECT v.montant, v.date, u.nom as membre_nom FROM versements v JOIN users u ON v.user_id = u.id WHERE v.tontine_id = ? ORDER BY v.date DESC");
$stmt->execute([$tontine_id]);
$versements = $stmt->fetchAll();

// Tours
$stmt = $db->prepare("SELECT numero, date, status FROM tours WHERE tontine_id = ? ORDER BY date ASC");
$stmt->execute([$tontine_id]);
$tours = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($page_title) ?></title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f2f4f8;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 25px;
        }

        .card {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0,0,0,0.08);
            margin-bottom: 40px;
        }

        .card p {
            margin: 8px 0;
            color: #444;
        }

        h3 {
            margin-top: 40px;
            text-align: center;
            color: #007BFF;
        }

        table {
            width: 100%;
            max-width: 800px;
            margin: 15px auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 0 6px rgba(0,0,0,0.05);
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }

        th {
            background-color: #e9ecef;
        }

        .btn {
            display: inline-block;
            padding: 10px 14px;
            background-color: #28a745;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            margin: 15px 5px;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #218838;
        }

        .actions {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>

    <h2>📋 Détails de la tontine : <?= htmlspecialchars($tontine['nom']) ?></h2>

    <div class="card">
        <p><strong>🧑‍💼 Créateur :</strong> <?= htmlspecialchars($tontine['createur_nom']) ?></p>
        <p><strong>💬 Description :</strong> <?= nl2br(htmlspecialchars($tontine['description'])) ?></p>
        <p><strong>💰 Montant :</strong> <?= number_format($tontine['montant'], 2) ?> FCFA</p>
        <p><strong>📆 Fréquence :</strong> <?= ucfirst($tontine['frequence']) ?></p>
        <p><strong>📅 Démarrage :</strong> <?= date('d/m/Y', strtotime($tontine['date_debut'])) ?></p>
        <p><strong>🗓 Créée le :</strong> <?= date('d/m/Y', strtotime($tontine['created_at'])) ?></p>
        <p><strong>📌 Statut :</strong> <?= ucfirst($tontine['statut'] ?? 'actif') ?></p>
    </div>

    <h3>🧍 Membres</h3>
    <table>
        <tr><th>Nom</th><th>Email</th><th>Téléphone</th></tr>
        <?php foreach ($membres as $membre): ?>
            <tr>
                <td><?= htmlspecialchars($membre['nom']) ?></td>
                <td><?= htmlspecialchars($membre['email']) ?></td>
                <td><?= htmlspecialchars($membre['telephone']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h3>💳 Versements</h3>
    <table>
        <tr><th>Membre</th><th>Montant</th><th>Date</th></tr>
        <?php foreach ($versements as $v): ?>
            <tr>
                <td><?= htmlspecialchars($v['membre_nom']) ?></td>
                <td><?= number_format($v['montant'], 2) ?> FCFA</td>
                <td><?= date('d/m/Y', strtotime($v['date'])) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h3>🔁 Tours</h3>
    <table>
        <tr><th>Tour</th><th>Date</th><th>Statut</th></tr>
        <?php foreach ($tours as $tour): ?>
            <tr>
                <td>Tour <?= $tour['numero'] ?></td>
                <td><?= date('d/m/Y', strtotime($tour['date'])) ?></td>
                <td><?= ucfirst($tour['status']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div class="actions">
        <a href="tontines.php" class="btn">← Retour à la liste</a>
        <?php if ($tontine['createur_id'] == $_SESSION['user_id']): ?>
            <a href="modifier_membres.php?tontine_id=<?= $tontine_id ?>" class="btn">✏️ Modifier les membres</a>
        <?php endif; ?>
    </div>

</body>
</html>