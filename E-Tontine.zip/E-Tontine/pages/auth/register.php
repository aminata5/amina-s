<?php
require_once('../../includes/config.php');

$page_title = "Inscription - E-Tontine";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom       = sanitize($_POST['nom']);
    $email     = sanitize($_POST['email']);
    $telephone = sanitize($_POST['telephone']);
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {
        $stmt = $db->prepare("INSERT INTO users (nom, email, telephone, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nom, $email, $telephone, $password]);

        $_SESSION['success'] = "✅ Inscription réussie ! Connectez-vous maintenant.";
        redirect('login.php');
    } catch(PDOException $e) {
        $_SESSION['error'] = "❌ Erreur : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title><?= $page_title ?></title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(to right, #00c6ff, #0072ff);
      font-family: 'Segoe UI', sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .register-box {
      background: white;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      max-width: 450px;
      width: 100%;
      text-align: center;
    }
    .register-box img {
      max-width: 80px;
      margin-bottom: 12px;
    }
    h1 {
      margin-bottom: 16px;
      color: #007bff;
    }
    .form-group {
      text-align: left;
      margin-bottom: 18px;
    }
    .form-group label {
      display: block;
      margin-bottom: 6px;
      font-weight: 600;
      color: #333;
    }
    .form-group input {
      width: 100%;
      padding: 10px;
      font-size: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }
    small#password-strength {
      display: block;
      font-size: 13px;
      margin-top: 4px;
      color: gray;
    }
    button {
      width: 100%;
      padding: 12px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    button:hover {
      background: #0056b3;
    }
    .alert {
      padding: 12px;
      margin-bottom: 20px;
      border-radius: 6px;
      font-size: 14px;
    }
    .alert.error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    .alert.success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    .login-link {
      margin-top: 10px;
      font-size: 14px;
    }
    .login-link a {
      color: #007bff;
      text-decoration: none;
    }
    .login-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="register-box">
  <img src="../assets/img/logo.png" alt="Logo E-Tontine">
  <h1>📝 Inscription</h1>

  <?php if (isset($_SESSION['error'])): ?>
    <div class="alert error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php endif; ?>

  <?php if (isset($_SESSION['success'])): ?>
    <div class="alert success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="form-group">
      <label for="nom">👤 Nom complet</label>
      <input type="text" name="nom" id="nom" required value="<?= isset($_POST['nom']) ? htmlspecialchars($_POST['nom']) : '' ?>">
    </div>

    <div class="form-group">
      <label for="email">📧 Email</label>
      <input type="email" name="email" id="email" required value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
    </div>

    <div class="form-group">
      <label for="telephone">📱 Téléphone</label>
      <input type="text" name="telephone" id="telephone" required value="<?= isset($_POST['telephone']) ? htmlspecialchars($_POST['telephone']) : '' ?>">
    </div>

    <div class="form-group">
      <label for="password">🔒 Mot de passe</label>
      <input type="password" name="password" id="password" required>
      <small id="password-strength"></small>
    </div>

    <button type="submit">S'inscrire</button>
  </form>

  <div class="login-link">
    Déjà inscrit ? <a href="login.php">Connectez-vous ici</a>
  </div>
</div>

<script>
  const password = document.getElementById('password');
  const strength = document.getElementById('password-strength');
  password.addEventListener('input', () => {
    const val = password.value;
    if (val.length < 6) {
      strength.textContent = '🔴 Faible';
      strength.style.color = 'red';
    } else if (val.match(/[A-Z]/) && val.match(/[0-9]/)) {
      strength.textContent = '🟢 Fort';
      strength.style.color = 'green';
    } else {
      strength.textContent = '🟠 Moyen';
      strength.style.color = 'orange';
    }
  });
</script>

</body>
</html>