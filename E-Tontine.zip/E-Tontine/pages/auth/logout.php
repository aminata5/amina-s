<?php
session_start();
session_unset();
session_destroy();
header("Location: ../../index.php"); // chemin relatif vers la racine de E-Tontine
exit();