<?php
require_once '../../includes/config.php';

$page_title = "Connexion";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];

    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['user_nom'] = $user['nom'];
        $_SESSION['user_email'] = $user['email'];
        redirect('../dashboard.php');
    } else {
        $_SESSION['error'] = "Email ou mot de passe incorrect";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title><?= $page_title ?></title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #00c6ff, #007bff);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .login-box {
      background: white;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
      max-width: 400px;
      width: 100%;
      text-align: center;
    }
    .login-box h2 {
      margin-bottom: 20px;
      color: #007bff;
    }
    .form-group {
      text-align: left;
      margin-bottom: 18px;
    }
    .form-group label {
      display: block;
      margin-bottom: 6px;
      font-weight: 600;
      color: #333;
    }
    .form-group input {
      width: 100%;
      padding: 10px;
      font-size: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }
    button {
      width: 100%;
      padding: 12px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    button:hover {
      background: #0056b3;
    }
    .alert {
      background-color: #f8d7da;
      color: #721c24;
      padding: 12px;
      margin-bottom: 20px;
      border-radius: 6px;
      border: 1px solid #f5c6cb;
    }
    .footer {
      margin-top: 15px;
      font-size: 14px;
      color: #555;
    }
    .footer a {
      color: #007bff;
      text-decoration: none;
    }
    .footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="login-box">
  <h2>🔐 Connexion à E-Tontine</h2>

  <?php if (isset($_SESSION['error'])): ?>
      <div class="alert"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="form-group">
      <label for="email">📧 Adresse email</label>
      <input type="email" id="email" name="email" required>
    </div>

    <div class="form-group">
      <label for="password">🔒 Mot de passe</label>
      <input type="password" id="password" name="password" required>
    </div>

    <button type="submit">Se connecter</button>
  </form>

  <div class="footer">
    Pas encore de compte ? <a href="register.php">Inscrivez-vous ici</a>
  </div>
</div>

</body>
</html>