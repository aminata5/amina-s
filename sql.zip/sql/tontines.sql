-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 13 juil. 2025 à 18:42
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `e_tontine`
--

-- --------------------------------------------------------

--
-- Structure de la table `tontines`
--

CREATE TABLE `tontines` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `montant` decimal(10,2) NOT NULL,
  `frequence` enum('quotidien','hebdomadaire','mensuel') DEFAULT 'mensuel',
  `date_debut` date DEFAULT NULL,
  `createur_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `tontines`
--

INSERT INTO `tontines` (`id`, `nom`, `description`, `montant`, `frequence`, `date_debut`, `createur_id`, `created_at`) VALUES
(1, 'Maouloud Fall', 'mlknlk', 45555.00, 'mensuel', NULL, 1, '2025-06-27 18:55:24'),
(2, 'Maouloud Fall', 'bljhbjhb', 97687.00, 'hebdomadaire', NULL, 1, '2025-06-27 18:58:31'),
(3, 'Maouloud Fall', 'Je suis interesé', 200000.00, 'mensuel', NULL, 2, '2025-07-10 13:23:13'),
(4, 'Arbre', 'Tontine Arbre', 10000.00, 'mensuel', '2025-07-11', 1, '2025-07-10 14:20:52'),
(5, 'Natte Tégui', 'Chaque fin du mois Natte Tégui', 10000.00, 'hebdomadaire', '2025-07-20', 4, '2025-07-12 22:29:49');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `tontines`
--
ALTER TABLE `tontines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `createur_id` (`createur_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `tontines`
--
ALTER TABLE `tontines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `tontines`
--
ALTER TABLE `tontines`
  ADD CONSTRAINT `tontines_ibfk_1` FOREIGN KEY (`createur_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
