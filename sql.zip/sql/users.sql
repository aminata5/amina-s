-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 13 juil. 2025 à 18:43
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `e_tontine`
--

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(20) DEFAULT 'membre'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `email`, `telephone`, `password`, `created_at`, `role`) VALUES
(1, 'Maouloud Fall', 'fall@gmail.com', '776993864', '$2y$10$ZewdRZJoTZaihT0rYs2F9Owph/5NVc.QWX22MbwMABZsDr.90vCQu', '2025-06-27 18:54:47', 'membre'),
(2, 'Maouloud Fall', 'fallmaouloud249@gmail.com', '776993864', '$2y$10$JdYiDdHOmiYswKATc6JF4.D/C3Sxn.5X0MTXkqptkMGnkk2pcocBO', '2025-07-10 13:15:58', 'moderateur'),
(3, 'Admin', 'admin@gmail.com', '786578197', '$2y$10$Z7VfOlNq1ZG/KEoZPNWTUe9VsFUnDdjq5/d5H8vNF2etuhsM/Dpqi', '2025-07-10 18:23:08', 'membre'),
(4, 'Admin1', 'admin1@gmail.com', '776677777', '$2y$10$7PR4mMb.83c8a2M8uR0xF.22qnLZVQrbCyX510J3uUpMXuSbUZKKq', '2025-07-10 20:29:31', 'membre');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
