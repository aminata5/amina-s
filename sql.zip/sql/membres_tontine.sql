-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 13 juil. 2025 à 18:41
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `e_tontine`
--

-- --------------------------------------------------------

--
-- Structure de la table `membres_tontine`
--

CREATE TABLE `membres_tontine` (
  `tontine_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_ajout` timestamp NOT NULL DEFAULT current_timestamp(),
  `cin_numero` varchar(100) DEFAULT NULL,
  `cin_fichier` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `membres_tontine`
--

INSERT INTO `membres_tontine` (`tontine_id`, `user_id`, `date_ajout`, `cin_numero`, `cin_fichier`) VALUES
(1, 1, '2025-07-10 16:59:34', '6775665', 'cin_686ff176d130d_Capture d\'écran 2025-07-07 002403.png'),
(1, 2, '2025-07-10 16:54:24', '2345', 'cin_686ff040c784f_Capture d\'écran 2025-07-07 002403.png');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `membres_tontine`
--
ALTER TABLE `membres_tontine`
  ADD PRIMARY KEY (`tontine_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `membres_tontine`
--
ALTER TABLE `membres_tontine`
  ADD CONSTRAINT `membres_tontine_ibfk_1` FOREIGN KEY (`tontine_id`) REFERENCES `tontines` (`id`),
  ADD CONSTRAINT `membres_tontine_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
